---
name: personal-website-astro
description: "用 WorkBuddy 快速搭建并上线个人网站（在线简历 + 技术博客）的可复用工作流。当用户希望用 Ardot 设计个人主页或简历网站、托管到 GitHub Pages、用 Astro 生成静态站点并自动部署、接入 Giscus 评论、或从零到上线个人网站时触发。覆盖设计（极简黑白）→ 工程脚手架（Astro 内容集合）→ 自动部署（GitHub Actions + Pages）→ 评论（Giscus）→ 写作发布（博客）的完整链路，并内置多 SSH 账号、Node 版本、Pages Source 设置等高频踩坑点。"
agent_created: true
---

# 用 WorkBuddy 快速搭建个人网站（Astro + Giscus + GitHub Pages）

## Overview

本技能把"从零搭建一个个人网站（在线简历 + 技术博客）并免费托管到 GitHub Pages"的完整过程沉淀为可复用工作流。
视觉用 Ardot 设计（极简黑白），工程用 Astro（内容驱动 / 默认零 JS / Markdown 原生），
部署用 GitHub Actions 自动发版，评论用 Giscus（基于 GitHub Discussions）。

整体不依赖任何付费服务，推送即上线，全链路可在 WorkBuddy 内完成。

## When to use

- 用户说"帮我做个个人网站 / 简历站 / 技术博客""托管到 GitHub Pages"。
- 用户希望"用 Ardot 设计个人主页""做一个极简黑白风格的网站"。
- 用户要"用 Astro 生成静态站点""接入 Giscus 评论""自动部署到 GitHub Pages"。
- 用户正在排查部署问题：404、CI 构建失败（Node 版本）、SSH key 冲突、Giscus 报错。

## 工作流总览

```
Phase A  设计   → Ardot 画极简黑白稿（设计令牌见下）
Phase B  工程   → 脚手架 Astro 项目（关键文件见 references/templates.md）
Phase C  部署   → GitHub Actions + Pages 自动发布（步骤见 references/deploy-guide.md）
Phase D  评论   → Giscus 接入（Discussions + App + repoId/categoryId）
Phase E  写作   → 在 src/content/blog/ 写 Markdown，push 即发布
```

默认采用**用户页仓库** `username.github.io`（访问 `https://username.github.io/`）。
如果用户明确要项目页（`my-website` → `https://username.github.io/my-website/`），记得 `ASTRO_BASE` 改为 `/my-website`。

---

## Phase A — 设计（Ardot，极简黑白）

通过 `ardot-design-core` + `ardot-ui-design` 在画布上出稿。设计令牌（已验证可用）：

| 令牌 | 值 | 说明 |
| --- | --- | --- |
| 画布底 `canvas` | `#EFEEEA` | 暖灰，非纯白 |
| 白卡 `card` | `#FFFFFF` | 卡片/容器 |
| 发丝线 `border` | `#000000` | 1px 细线分隔 |
| 强调红 `accent` | `#C8102E` | 链接/重点 |
| 字体 | Noto Sans SC / Inter / Roboto Mono | 中文正文 / 西文 / 代码 |
| 圆角 | `2px` | 几乎直角 |
| 阴影 | 无 | 零阴影，靠发丝线与留白分区 |

风格原则：大量留白、网格对齐、零阴影、发丝线分区、唯一的强调红点睛。
出稿后用 `capture_screenshot` 自检（产物存 `.workbuddy/screenshots/`，不要外传路径）。

工程侧无需导出设计稿文件——视觉令牌直接落到 `src/styles/global.css` 的 CSS 变量里（见 templates.md）。

---

## Phase B — 工程脚手架（Astro）

创建 Astro 项目（Node ≥ 22.12.0，见 Phase C 备注），关键文件与完整代码见
`references/templates.md`，包括：

- `astro.config.mjs`：`output: 'static'`、`site` 设为用户页地址、`base: process.env.ASTRO_BASE || '/'`。
- `src/content.config.ts`：blog 内容集合 schema（title / description / pubDate / tags / draft）。
- `src/styles/global.css`：设计令牌（CSS 变量，暗色用 `prefers-color-scheme` 自动切换）。
- `src/layouts/BaseLayout.astro`：站点名、SEO meta、引入 Giscus。
- `src/components/`：`Header` `Footer` `BlogCard` `FormattedDate` `Giscus`。
- `src/pages/`：`index` `about` `blog/index` `blog/[...slug]`。
- 博客文章：`src/content/blog/*.md`（frontmatter 见下）。

**本地开发（代理环境必看）**：若 `npm install` 报 TLS/网络错误，先 `source ~/.bash_profile` 让代理生效再装。
开发地址 `http://localhost:4321/`（本地 `base` 为 `/`，不带仓库名）。

---

## Phase C — 部署（GitHub Actions + Pages）

完整步骤与命令见 `references/deploy-guide.md`。要点速记：

1. 新建仓库（用户页 `username.github.io` 或项目页 `my-website`）。
2. 改占位：`astro.config.mjs` 的 `site`；`Footer/about/Giscus` 里的用户名与邮箱。
3. `.github/workflows/deploy.yml`：`node-version: 22`（⚠️ 不能用 20，Astro 要求 ≥22.12.0）、`ASTRO_BASE`（用户页 `/`，项目页 `/my-website`）。
4. 推送后到仓库 **Settings → Pages → Source 选 "GitHub Actions"**（⚠️ 别选 "Deploy from a branch"，否则 404）。
5. push 到 `main` 触发 Actions，跑完即上线。

**多 SSH 账号冲突**（常见报错 `Key is already in use` / `Permission denied to ...`）：
- 生成独立密钥 `ssh-keygen -t ed25519 -f ~/.ssh/id_ed25519_formyresume`；
- 在 `~/.ssh/config` 加别名，把该仓库 remote 改成 `git@github-formyresume:owner/repo.git`；
- 若 SSH 被墙，用 `Host github-formyresume` + `HostName ssh.github.com` + `Port 443`。

---

## Phase D — 评论（Giscus）

1. 仓库开启 **Discussions**（Settings 勾选）。
2. 安装 [Giscus App](https://github.com/apps/giscus) 并授权本仓库。
3. Discussions 新建分类 **Announcements**（Announcement 类型）。
4. 到 [giscus.app](https://giscus.app) 填仓库、`mapping: pathname`、分类 `Announcements`，复制 `data-repo / data-repo-id / data-category / data-category-id`。
5. 填入 `src/components/Giscus.astro` 顶部 `giscusConfig` 与 `<script>` 的 `config`（两处都要改）。
6. 未配置时优雅降级：文章页显示"评论功能即将开启"，不影响构建发布（见 templates.md 的 `enabled` 判断）。

⚠️ 报错 `giscus is not installed on this repository` 通常是因为 GitHub 侧还没装 App 或 Discussions 没开——先确认仓库侧，再核对 repoId/categoryId。

---

## Phase E — 写作与发布

在 `src/content/blog/` 新建 `.md`：

```markdown
---
title: '文章标题'
description: '一句话描述'
pubDate: 2026-07-22
tags: ['标签1', '标签2']
draft: false   # true 则不发布
---

正文，支持完整 Markdown、代码高亮（shiki 亮/暗双主题）。
```

保存并 `git push` → GitHub Actions 自动构建部署，约 30 秒上线。
要"总结过程沉淀成 skill + 发博客"时，就走 Phase E 把总结写成一篇博客推上去。

---

## 踩坑检查清单（上线前自查）

- [ ] `node-version: 22` 且本地 Node ≥ 22.12.0（CI 用 20 会 `not supported by Astro`）。
- [ ] Pages **Source = GitHub Actions**（不是 Deploy from a branch）。
- [ ] `ASTRO_BASE` 与仓库类型匹配（用户页 `/`，项目页 `/my-website`）。
- [ ] `astro.config.mjs` 的 `site` 已改为真实地址。
- [ ] SSH：多账号用独立密钥 + config 别名，remote 走别名而不是默认 `github.com`。
- [ ] Giscus：Discussions 已开 + App 已装 + repoId/categoryId 已填两处。
- [ ] 个人信息（姓名/邮箱/微信/社交链接）已从占位替换。
- [ ] `npm install` 失败时先 `source ~/.bash_profile` 让代理生效。

## Resources

- `references/templates.md` — 全部关键文件的完整可复制代码（astro.config / deploy.yml / content.config / Giscus / BaseLayout / Header / Footer / global.css 设计令牌 / 博客模板）。
- `references/deploy-guide.md` — GitHub 仓库创建、占位替换、SSH 多账号配置、Pages 设置、推送命令的完整 runbook。
