# 关键文件完整模板（Astro 个人网站）

复制以下文件到对应路径即可搭建基础站点。所有 `你的用户名 / 你的邮箱` 占位需替换。

---

## astro.config.mjs

```javascript
import { defineConfig } from 'astro/config';

export default defineConfig({
  // 用户页仓库 username.github.io：site 设为 https://username.github.io，base 保持 '/'
  // 项目页仓库 my-website：site 设为 https://username.github.io，base 设为 '/my-website'
  //   部署时经 deploy.yml 的 ASTRO_BASE 注入，无需改这里
  site: 'https://你的用户名.github.io',
  base: process.env.ASTRO_BASE || '/',

  // GitHub Pages 需要静态输出
  output: 'static',

  markdown: {
    shikiConfig: {
      themes: { light: 'github-light', dark: 'github-dark' },
      wrap: true,
    },
  },
});
```

---

## .github/workflows/deploy.yml

```yaml
name: Deploy to GitHub Pages

on:
  push:
    branches: [main]
  workflow_dispatch:

permissions:
  contents: read
  pages: write
  id-token: write

concurrency:
  group: pages
  cancel-in-progress: false

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Setup Node
        uses: actions/setup-node@v4
        with:
          node-version: 22          # ⚠️ 必须 22，Astro 要求 >=22.12.0；用 20 会构建失败
          cache: npm

      - name: Install dependencies
        run: npm ci

      - name: Build with Astro
        run: npm run build
        env:
          # 项目页仓库（如 my-website）设为 /my-website；用户页仓库（username.github.io）设为 /
          ASTRO_BASE: /

      - name: Upload artifact
        uses: actions/upload-pages-artifact@v3
        with:
          path: ./dist

  deploy:
    needs: build
    runs-on: ubuntu-latest
    environment:
      name: github-pages
      url: ${{ steps.deployment.outputs.page_url }}
    steps:
      - name: Deploy to GitHub Pages
        id: deployment
        uses: actions/deploy-pages@v4
```

---

## src/content.config.ts

```typescript
import { glob } from 'astro/loaders';
import { defineCollection, z } from 'astro:content';

const blog = defineCollection({
  loader: glob({ pattern: '**/*.md', base: './src/content/blog' }),
  schema: z.object({
    title: z.string(),
    description: z.string(),
    pubDate: z.coerce.date(),
    updatedDate: z.coerce.date().optional(),
    tags: z.array(z.string()).default([]),
    draft: z.boolean().default(false),
  }),
});

export const collections = { blog };
```

---

## src/styles/global.css（设计令牌 · 极简黑白）

```css
:root {
  --color-canvas: #EFEEEA;   /* 暖灰底 */
  --color-card: #FFFFFF;     /* 白卡 */
  --color-text: #111111;     /* 主文字 */
  --color-text-secondary: #555555;
  --color-border: #000000;   /* 发丝线 */
  --color-accent: #C8102E;   /* 强调红 */
  --radius: 2px;
  --font-sans: 'Noto Sans SC', 'Inter', system-ui, sans-serif;
  --font-mono: 'Roboto Mono', monospace;
}
@media (prefers-color-scheme: dark) {
  :root {
    --color-canvas: #15151a;
    --color-card: #1d1d22;
    --color-text: #eeeeee;
    --color-text-secondary: #aaaaaa;
    --color-border: #3a3a40;
    --color-accent: #ff3355;
  }
}
* { box-sizing: border-box; }
body {
  margin: 0;
  background: var(--color-canvas);
  color: var(--color-text);
  font-family: var(--font-sans);
  line-height: 1.7;
}
a { color: var(--color-accent); }
```

---

## src/components/Giscus.astro（评论 · 未配置优雅降级）

```astro
---
interface Props { class?: string }

const giscusConfig = {
  repo: '你的用户名/你的仓库',          // owner/repo
  repoId: 'R_xxxx',                   // 从 giscus.app 获取
  category: 'Announcements',
  categoryId: 'DIC_xxxx',             // 从 giscus.app 获取
  mapping: 'pathname',
  reactionsEnabled: '1',
  emitMetadata: '0',
  inputPosition: 'top',
  theme: 'prefers_color_scheme',
  lang: 'zh-CN',
};

// 未配置（仍为占位 R_xxxx）时降级，避免 giscus 加载报错
const enabled = !giscusConfig.repoId.includes('xxxx');
---

{enabled ? (
  <section class="giscus-wrapper" {...Astro.props}>
    <h2 class="comments-heading">评论</h2>
    <div class="giscus"></div>
  </section>
) : (
  <section class="giscus-wrapper" {...Astro.props}>
    <h2 class="comments-heading">评论</h2>
    <p class="giscus-disabled">评论功能即将开启，敬请期待。</p>
  </section>
)}

{enabled && (
  <script>
    const config = {
      src: 'https://giscus.app/client.js',
      'data-repo': '你的用户名/你的仓库',
      'data-repo-id': 'R_xxxx',
      'data-category': 'Announcements',
      'data-category-id': 'DIC_xxxx',
      'data-mapping': 'pathname',
      'data-strict': '1',
      'data-reactions-enabled': '1',
      'data-emit-metadata': '0',
      'data-input-position': 'top',
      'data-theme': 'prefers_color_scheme',
      'data-lang': 'zh-CN',
      crossorigin: 'anonymous',
      async: '',
    };
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const script = document.createElement('script');
          Object.entries(config).forEach(([k, v]) => script.setAttribute(k, v as string));
          entry.target.querySelector('.giscus')?.appendChild(script);
          observer.disconnect();
        }
      });
    }, { rootMargin: '200px' });
    const wrapper = document.querySelector('.giscus-wrapper');
    if (wrapper) observer.observe(wrapper);
  </script>
)}

<style>
  .giscus-wrapper { margin-top: 3rem; padding-top: 2rem; border-top: 1px solid var(--color-border); }
  .comments-heading { font-size: 1.2rem; margin-bottom: 1.5rem; }
  .giscus { min-height: 100px; }
  .giscus-disabled { color: var(--color-text-secondary); font-size: 0.95rem; }
</style>
```

---

## src/layouts/BaseLayout.astro（片段）

```astro
---
import '../styles/global.css';
import Header from '../components/Header.astro';
import Footer from '../components/Footer.astro';
import Giscus from '../components/Giscus.astro';

interface Props {
  title: string;
  description?: string;
}
const { title, description = '个人网站' } = Astro.props;
const siteName = '你的名字';
---

<!doctype html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="description" content={description} />
    <title>{title} · {siteName}</title>
  </head>
  <body>
    <Header siteName={siteName} />
    <main class="container">
      <slot />
      <Giscus />
    </main>
    <Footer />
  </body>
</html>
```

---

## src/components/Footer.astro（社交链接 · 占位替换）

```astro
---
const year = new Date().getFullYear();
const socialLinks = [
  { label: 'GitHub', url: 'https://github.com/你的用户名' },
  { label: 'Email', url: 'mailto:你的邮箱@example.com' },
  { label: '微信', url: '' },   // 微信无外链，可写微信号文本
];
---
<footer class="site-footer">
  <div class="social">
    {socialLinks.map((l) => <a href={l.url}>{l.label}</a>)}
  </div>
  <p>© {year} 你的名字</p>
</footer>
```

---

## 博客文章模板（src/content/blog/your-post.md）

```markdown
---
title: '文章标题'
description: '一句话描述'
pubDate: 2026-07-22
tags: ['标签1', '标签2']
draft: false
---

正文，支持完整 Markdown 与代码高亮。保存并 push 即自动发布。
```
