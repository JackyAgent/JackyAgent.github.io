# 部署 Runbook：GitHub Pages（用户页 vs 项目页）

## 0. 前置环境

- **Node ≥ 22.12.0**：本地用 `/Users/yangjiaqi/.workbuddy/binaries/node/versions/22.22.2/bin/node`（托管版）。
- **代理**：`npm install` 报 TLS/网络错误时，先 `source ~/.bash_profile` 让代理生效。
- **Git**：本机已配好 git 身份（`git config user.name/email`）。

---

## 1. 新建仓库

- 用户页：`username.github.io` → 访问 `https://username.github.io/`
- 项目页：`my-website` → 访问 `https://username.github.io/my-website/`
- 仓库默认分支建议 `main`。

---

## 2. 替换占位

| 文件 | 要改的占位 |
| --- | --- |
| `astro.config.mjs` | `site: 'https://你的用户名.github.io'` |
| `src/components/Giscus.astro` | `repo` / `repoId` / `categoryId`（两处） |
| `src/components/Footer.astro` | GitHub 用户名、邮箱、微信 |
| `src/pages/about.astro` | 联系方式、个人简介 |
| `src/layouts/BaseLayout.astro` | `siteName` |
| `.github/workflows/deploy.yml` | `ASTRO_BASE`（用户页 `/`，项目页 `/my-website`） |

---

## 3. Pages Source 设置（高频 404 根因）

推送后到仓库 **Settings → Pages → Build and deployment → Source** 选择
**GitHub Actions**（⚠️ 不是 "Deploy from a branch"）。选错分支方式会一直 404。

---

## 4. 多 SSH 账号配置（Key is already in use）

当一个 SSH 公钥已绑到其他 GitHub 账号时，新建独立密钥并走别名：

```bash
# 1. 生成独立密钥
ssh-keygen -t ed25519 -f ~/.ssh/id_ed25519_formyresume -C "你的邮箱@example.com"
# 2. 把 ~/.ssh/id_ed25519_formyresume.pub 的内容加到「这个新仓库所属账号」的 SSH keys

# 3. 编辑 ~/.ssh/config
Host github-formyresume
  HostName ssh.github.com      # 若 github.com 被墙改用 ssh.github.com + 443
  Port 443
  User git
  IdentityFile ~/.ssh/id_ed25519_formyresume
  IdentitiesOnly yes
```

```bash
# 4. 测试
ssh -T git@github-formyresume
# 5. 把仓库 remote 指向别名（而不是默认 github.com）
git remote set-url origin git@github-formyresume:你的用户名/你的仓库.git
```

> 报错 `Permission denied to JackyAgent/... denied to JackyYangPassion` 通常是 remote 走了默认
> `github.com`（默认密钥属于另一个账号）。改用上面的别名 remote 即可。

---

## 5. 推送命令（用户自行执行）

```bash
git init
git add .
git commit -m "feat: 个人网站初版（Astro + Giscus）"
git branch -M main
git remote add origin git@github-formyresume:你的用户名/你的仓库.git   # 或 https 地址
git push -u origin main
```

推送后等待 Actions 跑完（约 30 秒～1 分钟），访问站点地址即上线。
后续每次 `git push` 都会自动重新部署。

---

## 6. 上线后验证清单

- [ ] 首页、/about、/blog、单篇文章页均可访问
- [ ] 文章底部评论区：已配 Giscus 显示评论框；未配则显示"评论功能即将开启"
- [ ] 暗色模式下配色切换正常
- [ ] Actions 最新一次运行绿色成功
